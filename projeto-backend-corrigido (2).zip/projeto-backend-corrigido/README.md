# Digital Store API - Projeto Backend

Uma API RESTful completa para e-commerce desenvolvida como projeto final do Projeto Backend do curso Desenvolvedor Web Full Stack da Geração Tech do Instituto Euvaldo Lodi (IEL). A aplicação oferece uma solução robusta para gerenciamento de produtos, usuários, categorias e sistema de autenticação para lojas virtuais.

##  Sobre o Projeto

Este projeto implementa uma API completa para e-commerce que demonstra domínio em desenvolvimento backend moderno, incluindo operações CRUD, autenticação segura, modelagem de dados e arquitetura escalável. A Digital Store API serve como base para qualquer aplicação de comércio eletrônico, fornecendo todos os recursos essenciais para gestão de produtos e usuários.

**Repositório de referência:** [https://github.com/digitalcollegebr/projeto-backend](https://github.com/digitalcollegebr/projeto-backend)

##  Tecnologias usadas no Projeto

O projeto foi desenvolvido com um conjunto de tecnologias modernas do JavaScript, garantindo eficiência, segurança e facilidade na manutenção:

### Tecnologias Essenciais
- **Node.js** - Runtime JavaScript para desenvolvimento server-side
- **Express.js** - Framework web minimalista e flexível para Node.js
- **Sequelize** - ORM avançado para Node.js com excelente integração ao MySQL
- **MySQL** - Sistema de gerenciamento de banco de dados relacional robusto e amplamente utilizado

### Comunicação com Banco
- **MySQL2** - Driver MySQL nativo para Node.js com suporte a Promises

### Segurança & Autenticação
- **JSON Web Tokens (JWT)** - Sistema de autenticação baseado em tokens
- **Bcrypt.js** - Biblioteca para criptografia segura de senhas
- **CORS** - Configuração para requisições cross-origin

### Desenvolvimento & Testes
- **Nodemon** - Ferramenta para reinicialização automática durante desenvolvimento
- **Jest** - Framework de testes JavaScript
- **C8** - Cobertura de código
- **Swagger UI** - Documentação interativa da API em `/api-docs`
- **Supertest** - Biblioteca para testes de APIs HTTP

##  Requisitos de Avaliação

### 1. Funcionalidades Essenciais
- Implementação completa dos endpoints especificados
- Operações CRUD para todas as entidades principais
- Sistema de autenticação e autorização robusto
- Tratamento adequado de erros e validações

### 2. Qualidade do Código
- Código limpo, comentado e bem estruturado
- Aplicação de boas práticas de desenvolvimento
- Arquitetura organizada seguindo padrões estabelecidos

### 3. Banco de Dados
- Modelagem eficiente e normalizada
- Implementação adequada de migrations
- Consultas otimizadas e relacionamentos bem definidos

### 4. Documentação
- Documentação completa da API
- Instruções claras de configuração
- Guias de uso e exemplos práticos

##  Principais Funcionalidades

### Gestão de Usuários
- Cadastro completo de usuários com validações
- Armazenamento seguro de credenciais com hash
- Sistema de autenticação via JWT
- Middleware de proteção para rotas privadas

### Gerenciamento de Produtos
- CRUD completo para produtos e suas variações
- Sistema de categorização flexível
- Gerenciamento de imagens e opções de produtos
- Busca avançada com múltiplos filtros

### Sistema de Categorias
- Organização hierárquica de produtos
- Operações completas de gerenciamento
- Associações dinâmicas com produtos

### Recursos Avançados
- Arquitetura em camadas (Controllers, Services, Models)
- Filtros de busca por nome, preço, categoria
- Servidor Express otimizado para alta performance
- Testes automatizados abrangentes

##  Endpoints da API

A API utiliza o prefixo /v1 para versionamento das rotas.

| Método   | Endpoint               | Descrição                            | 🔒 Autenticação |
| -------- | ---------------------- | ------------------------------------ | --------------- |
| `POST`   | `/user/token`          | Autenticação e geração de token JWT  | ❌ Não          |
| `GET`    | `/user/:id`            | Consultar usuário por ID             | ❌ Não          |
| `POST`   | `/user`                | Cadastar usuário                     | ❌ Não          |
| `PUT`    | `/user/:id`            | Atualizar usuário                    | ✔️ Sim          |
| `DELETE` | `/user/:id`            | Deletar usuário                      | ✔️ Sim          |
| `GET`    | `/category/search`     | Listar categoria com filtros         | ❌ Não          |
| `GET`    | `/category/slug/:slug` | Consultar categoria por slug         | ❌ Não          |
| `GET`    | `/category/:id`        | Consultar categoria por ID           | ❌ Não          |
| `POST`   | `/category`            | Cadastrar categoria                  | ✔️ Sim          |
| `PUT`    | `/category/:id`        | Atualizar categoria                  | ✔️ Sim          |
| `DELETE` | `/category/:id`        | Deletar categoria                    | ✔️ Sim          |
| `GET`    | `/product/search`      | Busca avançada de produtos           | ❌ Não          |
| `GET`    | `/product/slug/:slug`  | Consultar produto por slug           | ❌ Não          |
| `GET`    | `/product/:id`         | Consultar produto por ID             | ❌ Não          |
| `POST`   | `/product`             | Cadastrar produto                    | ✔️ Sim          |
| `PUT`    | `/product/:id`         | Atualizar produto                    | ✔️ Sim          |
| `DELETE` | `/product/:id`         | Deletar produto                      | ✔️ Sim          |


##  Configuração e Execução

### Pré-requisitos
- **Node.js** 18 ou superior
- **MySQL** 8 (ou MariaDB 10.5+) em execução
- **Git**

### Passo a passo

```bash
# 1. Clone o repositório e entre na pasta do backend
git clone <URL-DO-SEU-REPOSITÓRIO>
cd projeto-backend

# 2. Instale as dependências
npm install

# 3. Crie os bancos de dados (desenvolvimento e testes)
mysql -u root -p -e "CREATE DATABASE projeto_backend; CREATE DATABASE projeto_backend_test;"

# 4. Configure as variáveis de ambiente
cp .env.example .env      # depois edite .env com sua senha do MySQL e um JWT_SECRET

# 5. Crie as tabelas (migrations)
npm run migrate

# 6. (Opcional) Popule com dados de exemplo
npm run seed              # usuário de exemplo: admin@email.com / 123456

# 7. Inicie o servidor
npm run dev               # ou: npm start
```

A API sobe em **http://localhost:3000** e a documentação interativa em **http://localhost:3000/api-docs**.

### Variáveis de ambiente (`.env`)

| Variável | Descrição |
| --- | --- |
| `PORT` | Porta da API (padrão 3000) |
| `JWT_SECRET` | Segredo para assinar os tokens (obrigatório) |
| `DB_HOST`, `DB_PORT`, `DB_USER`, `DB_PASSWORD` | Conexão com o MySQL |
| `DB_NAME` | Banco de desenvolvimento |
| `DB_NAME_TEST` | Banco usado **somente** nos testes (padrão `<DB_NAME>_test`) |

>  Nunca faça commit do `.env`. Ele já está no `.gitignore`.

### Scripts

| Comando | O que faz |
| --- | --- |
| `npm run dev` | Servidor com reinício automático (nodemon) |
| `npm start` | Servidor em modo normal |
| `npm run migrate` / `npm run migrate:undo` | Aplica / desfaz as migrations |
| `npm run seed` | Insere dados de exemplo |
| `npm test` | Roda os testes (usa o banco `DB_NAME_TEST`, nunca o de desenvolvimento) |
| `npm run coverage` | Testes com relatório de cobertura |

##  Autenticação

1. Cadastre-se em `POST /v1/user` (ou use o usuário do seed).
2. Faça login em `POST /v1/user/token` com `email` e `password` e copie o `token`.
3. Envie `Authorization: Bearer <token>` nas rotas marcadas com 🔒. Token ausente ou inválido responde **401**.
4. Um usuário só pode alterar ou excluir **a si mesmo** (outro usuário responde **403**).

##  Busca de produtos (`GET /v1/product/search`)

| Parâmetro | Exemplo | Descrição |
| --- | --- | --- |
| `limit` | `12` | Itens por página; `-1` retorna todos (padrão 12) |
| `page` | `2` | Página (padrão 1) |
| `match` | `Tênis` | Busca no nome ou na descrição |
| `category_ids` | `15,24` | Produtos de qualquer uma das categorias |
| `price-range` | `100-200` | Faixa de preço |
| `option[45]` | `GG,PP` | Produtos cuja opção 45 tem algum dos valores |
| `fields` | `name,images,price` | Campos a retornar |

Os filtros podem ser combinados. A resposta tem o formato `{ data, total, limit, page }`.

##  Códigos de resposta

| Código | Quando |
| --- | --- |
| `200` / `201` / `204` | Sucesso (consulta / criação / atualização ou exclusão) |
| `400` | Dados ausentes ou inválidos |
| `401` | Token ausente ou inválido |
| `403` | Tentativa de alterar outro usuário |
| `404` | Registro ou rota inexistente |
| `500` | Erro inesperado (sem vazar detalhes) |

##  Estrutura do projeto

```
src/
├── config/        # conexão com o banco e configuração do sequelize-cli
├── controllers/   # camada HTTP: valida a entrada e monta a resposta
├── services/      # regras de negócio (produtos, imagens, hash, token)
├── validators/    # validação das entradas de produto
├── models/        # models Sequelize e relacionamentos
├── migrations/    # estrutura do banco (versionada)
├── seeders/       # dados de exemplo
├── middleware/    # autenticação JWT e tratamento global de erros
├── routes/        # definição das rotas /v1
├── docs/          # especificação OpenAPI (Swagger)
└── utils/         # funções auxiliares
tests/             # testes automatizados (Jest + Supertest)
```

##  Equipe

LUCAS MATHEUS DANTAS RIBEIRO

## Adicional

# Projeto Back-end - E-commerce (Digital Store)

API REST full-stack desenvolvida como projeto prático para a **Digital College**, cobrindo o gerenciamento de usuários, categorias, produtos e autenticação segura.

##  Tecnologias Utilizadas

- **Node.js** & **Express.js** (Ambiente de execução e rotas da API)
- **MySQL** & **Sequelize ORM** (Banco de dados e modelagem)
- **JSON Web Token (JWT)** & **Bcrypt** (Autenticação e criptografia de senhas)
- **Swagger (OAS 3.0)** (Documentação interativa da API)

---

##  Como Rodar o Projeto na Sua Máquina

Siga os passos abaixo para clonar, configurar e executar a aplicação localmente:

### 1. Clonar o Repositório
```bash
git clone https://github.com
cd projeto-backend
```

### 2. Instalar as Dependências
```bash
npm install
```

### 3. Configurar as Variáveis de Ambiente
Crie um arquivo chamado **`.env`** na raiz do projeto e configure as credenciais do seu banco de dados MySQL local:

```ini
PORT=3000
JWT_SECRET=sua_chave_secreta_aqui

DB_HOST=localhost
DB_USER=root
DB_PASS=389067Lm#
DB_NAME=digital_store
DB_DIALECT=mysql
```

### 4. Estrutura do Banco de Dados
Certifique-se de criar o banco de dados `digital_store` no seu MySQL. As tabelas serão geradas automaticamente pelo Sequelize ao iniciar a aplicação, ou você pode rodar as queries contidas na pasta de documentação.

### 5. Iniciar o Servidor de Desenvolvimento
```bash
npm run dev
```
O terminal exibirá a confirmação de que o banco de dados foi conectado com sucesso.

---

## 📖 Documentação da API (Swagger)

Com o servidor rodando localmente, acesse a documentação interativa para testar todos os endpoints (criar usuários, realizar login e gerenciar o catálogo):

🔗 **[http://localhost:3000/api-docs](http://localhost:3000/api-docs)**

*Nota: Para testar rotas protegidas (POST, PUT, DELETE), utilize o endpoint `/v1/user/token` para gerar o token JWT e insira-o no botão "Autorizar" no formato `Bearer <seu_token>`.*
